package com.efficientgoose.backend.shared.service;

public enum StatusNotification {
    OK, ERROR, UNAUTHORIZED;
}
